<link href="hoja_de_estilo.css" type="text/css" rel="stylesheet">

<body background="body2.jpg">

<div align="center" class="titulo_cabecera"><br>
  <br>
LOS PRODUCTOS SE REGISTRARON CORRECTAMENTE:
<br>
<br>
Podria ser necesario actualizar algunos datos de todos los productos actualizados
<br>
<br>
</div>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td class="title" width="7%">Codigo Producto</td>
    <td class="title" width="10%">Nombre</td>
    <td class="title" width="5%">Cantidad</td>
    <td class="title" width="10%">Marca</td>
    <td class="title" width="10%">Modelo</td>
    <td class="title" width="20%">Descripcion</td>
    <td class="title" width="10%">Imagen</td>
    <td class="title" width="5%">Editar producto</td>
  </tr>
<?php

if(!empty($_POST['uploadField']))
{

	require_once("manejomysql.php");
	conectar_bd();
	
	$file=$_POST['uploadField'];
	
	//echo $file;
	
	$fp = fopen ( $file , "r" ); 

		
//
	while (( $line_of_text = fgetcsv ( $fp , 1000 , "," )) !== FALSE)
		{
			$consulta="insert into producto values('$line_of_text[0]', '$line_of_text[1]', $line_of_text[2],0,'$line_of_text[3]','$line_of_text[4]',0,'$line_of_text[5]','activo', '$line_of_text[6]', null, null, null, null,0,0,0)";
			mysql_query($consulta) or die(header ("Location:registrar_producto.php?error_registro=2"));
			
			echo "<tr>
			  
    				<td class='campotablas'>$line_of_text[0]</td>
    				<td class='campotablas'>$line_of_text[1]</td>
    				<td class='campotablas'>$line_of_text[2]</td>
    				<td class='campotablas'>$line_of_text[3]</td>
    				<td class='campotablas'>$line_of_text[4]</td>
    				<td class='campotablas'>$line_of_text[5]</td>
    				<td class='campotablas'>$line_of_text[6]</td>
    				<td class='campotablas'>Editar</td>
  				</tr>";
			
		}

	fclose ( $fp ); 
	

}
else
{
	header ("Location:cargar_producto.php?error_registro=1");
	exit;

}

?>


</table>

