<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<p>PAGINA DE ERROR</p>
<p>&nbsp;</p>
<p><a href="registrar_cliente.php">Listar Clientes </a></p>
<p><a href="actualizar_cliente.php">Modificar Informacion de Cliente</a></p>
<p>Dar de Baja Cliente</p>
<p>&nbsp;</p>
</body>
</html>
