<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE EQUIPOS</p>
<p>&nbsp;</p>
<p><a href="registrar_cliente_equipo.php">Registrar Asignacion de Equipo al Cliente</a></p>
<p><a href="buscar_equipo.php">Modificar Asignacion de Equipo</a></p>
<p><a href="quitar_equipo.php">Quitar Asignacion de Equipo al Cliente</a></p>
<p><a href="registrar_cliente_equipo2.php">Asignacion de Botellones al Cliente</a></p>
<p><a href="modificar_quitar_botellones.php">Modificar / Quitar Asignacion de Botellones al Cliente</a></p>
<p><a href="registrar_cliente_cambio.php">Registrar Cambios</a></p>
<p><a href="registrar_cliente_cambio.php">Mostrar Equipos que fueron cambiados</a></p>
<p><a href="equipos_empresa.php">Equipos de la Empresa</a></p>

<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
