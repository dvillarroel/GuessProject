<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>SOLICITUD DE PEDIDO</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="hoja_de_estilo.css" type="text/css" rel="stylesheet">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>
<?php 
	$codigo_cliente=$_GET['id_cliente'];
	$codigo_pedido=$_GET['id_pedido'];
	
	require_once("manejomysql.php");
	conectar_bd();

	$usuario_consulta = mysql_query("SELECT ci_cliente, nombre_cliente, apellido_paterno, apellido_materno, direccion_cliente, telefono_cliente, observaciones_cliente FROM cliente WHERE codigo_cliente=$codigo_cliente;" );
	$registro= sacar_registro_bd($usuario_consulta);

	$ci=$registro['ci_cliente'];
	$nombre_completo=$registro['nombre_cliente']." ".$registro['apellido_paterno']." ".$registro['apellido_materno'];
	$direccion=$registro['direccion_cliente'];
	$telefono=$registro['telefono_cliente'];
	$observaciones_cliente=$registro['observaciones_cliente'];
	
	
	$usuario_consulta = mysql_query("SELECT cod_pedido, fecha, monto_total, estado FROM pedido WHERE cod_pedido=$codigo_pedido;" );	

	$a=sacar_registro_bd($usuario_consulta);
	$fecha_pedido=$a["fecha"];
	$partirFecha=split("-",$fecha_pedido);
	$monto_total=$a["monto_total"];
	$estado_pedido=$a["estado"];
	

	//echo $codigo_cliente;
	//echo $codigo_pedido;
	

?>
<div id="Layer5" style="position:absolute; left:13px; top:6px; width:115px; height:86px; z-index:5"><img src="pl%E1stico_tapas.bmp" width="110" height="78"></div>
<div id="Layer1" style="position:absolute; left:456px; top:22px; width:138px; height:41px; z-index:1">
  <table width="100%" border="1" align="center" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="35%" class="campotablasSP2"><div align="center">Dia</div></td>
      <td width="25%" class="campotablasSP2"><div align="center">Mes</div></td>
      <td width="40%"  class="campotablasSP2"><div align="center">A&ntilde;o</div></td>
    </tr>
    <tr> 
      <td class="campotablasSP"><div align="center"><? echo $partirFecha[2];?></div></td>
      <td class="campotablasSP"><div align="center"><? echo $partirFecha[1];?></div></td>
      <td class="campotablasSP"><div align="center"><? echo $partirFecha[0];?></div></td>
    </tr>
  </table>
</div>
<div id="Layer2" style="position:absolute; left:161px; top:41px; width:279px; height:36px; z-index:2"><font size="3" class="campotablas"><strong>SOLICITUD 
  DE PEDIDOS</strong></font></div>
<div id="Layer8" style="position:absolute; left:14px; top:101px; width:580px; height:1004px; z-index:8"> 
  
  <? $usu = mysql_query("SELECT cod_pedido, codigo_cliente, fecha, monto_total, 
  estado FROM pedido WHERE estado='No Ejecutado' and monto_total>0;" ); 
  
  if (mysql_num_rows($usu) != 0) 
  {
  		for ( $j=0; $j< cuantos_registros_bd($usu); $j++)
		{
//			echo 'numero de cliente'.$j;
			
			$a=sacar_registro_bd($usu);
			$cod_pedido=$a['cod_pedido'];
			$codigo_cliente=$a['codigo_cliente'];
  				
		  	$usuario_consulta = mysql_query("SELECT ci_cliente, nombre_cliente, apellido_paterno, apellido_materno, direccion_cliente, telefono_cliente, observaciones_cliente FROM cliente WHERE codigo_cliente=$codigo_cliente;" );
			$registro= sacar_registro_bd($usuario_consulta);

			$ci=$registro['ci_cliente'];
			$nombre_completo=$registro['nombre_cliente']." ".$registro['apellido_paterno']." ".$registro['apellido_materno'];
			$direccion=$registro['direccion_cliente'];
			$telefono=$registro['telefono_cliente'];
			$observaciones_cliente=$registro['observaciones_cliente'];			
  
  		echo' 
  <table width="98%" border="0" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="14%" class="campotablasSP3">Se&ntilde;or(a): </td>
      <td width="45%" class="campotablasSP3">&nbsp;'.$nombre_completo.'</td>
      <td width="10%" class="campotablasSP3">C.I. Nr.:</td>
      <td width="31%" class="campotablasSP3">&nbsp;'.$ci.'</td>
    </tr>
    <tr> 
      <td class="campotablasSP3">Direcci&oacute;n: </td>
      <td class="campotablasSP3">&nbsp;'.$direccion.'</td>
      <td class="campotablasSP3">Telefono:</td>
      <td class="campotablasSP3">&nbsp;'.$telefono.'</td>
    </tr>
    <tr> 
      <td colspan="4" class="campotablasSP3">De acuerdo a solicitud del cliente, remitimos a Ud. el siguiente 
        pedido:</td>
    </tr>
  </table>
  <br>

  <table width="99%" border="1" cellpadding="0" cellspacing="0">
    <tr> 
      <td width="15%" class="campotablasSP2"><div align="center">Codigo Equipo</div></td>
      <td width="10%" class="campotablasSP2"><div align="center">Cantidad</div></td>
      <td width="44%" class="campotablasSP2"><div align="center">Descripci&oacute;n</div></td>
      <td width="10%" class="campotablasSP2"><div align="center">P/Unit.</div></td>
      <td width="21%" class="campotablasSP2"><div align="center">Total </div></td>
    </tr>';
    
	$usuario_consulta = mysql_query("SELECT cantidad, monto, precio_unitario, cod_dp, cod_producto, cod_equipo FROM detalle_pedido WHERE cod_pedido=".$cod_pedido);	
	
	for ( $i=0; $i< cuantos_registros_bd($usuario_consulta); $i++)
	{
		echo '<tr>'; 
	    
		$a=sacar_registro_bd($usuario_consulta);
					
		$codigo_producto=$a['cod_producto'];
		$codigo_dp=$a['cod_dp'];
		$cantidad=$a['cantidad'];
		$monto=$a['monto'];
		$precio_unitario=$a['precio_unitario'];
		$cod_equipo=$a['cod_equipo'];
				
		$usuario_consulta2 = mysql_query("SELECT nombre_producto FROM producto WHERE cod_producto=$codigo_producto;" );	
		$a=sacar_registro_bd($usuario_consulta2);
		$nombre_producto=$a['nombre_producto'];
			
		echo "
		
		<td class='campotablasSP'>";
		if(!empty($cod_equipo))
		{
			echo $cod_equipo;
		}
		else
		{
			echo"Sin equipo";
		}
		echo "</td>";
		
		echo "
		<td class='campotablasSP'>".$cantidad."</td>
		<td class='campotablasSP'>".$nombre_producto."</td>
		<td class='campotablasSP'>".$precio_unitario."</td>
		<td class='campotablasSP'><div align='center'>".$monto."</div></td>
		";
		
		echo '</tr>';	
					
	}



	echo '

    <tr> 
      <td colspan="4" class="campotablasSP">Total Bs.</td>
      <td class="campotablasSP2"><div align="center">&nbsp'.$monto_total.'</div></td>
    </tr>
  </table>
  
  
  
  <br>
  <div id="Layer4">Observaciones:'; 
//  $codigo_cliente=$codigo_cliente;
	//$usuario_consulta = mysql_query("SELECT observaciones_cliente FROM cliente WHERE codigo_cliente=$codigo_cliente;" );
	//$registro= sacar_registro_bd($usuario_consulta);
	//$observaciones_cliente=$registro['observaciones_cliente'];
  echo $observaciones_cliente.'<br>
  ================================================================</div>';

  }

}


  ?>
</div>

</body>
</html>
