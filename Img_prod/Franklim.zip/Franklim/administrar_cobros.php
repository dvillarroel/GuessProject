<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION COBROS</p>
<p>&nbsp;</p>
<p><a href="lista_por_cobrar.php">Lista de Pedidos por Cobrar</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
