<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRAR PEDIDOS</p>
<p><a href="buscar_cliente_pedido.php">Realizar Pedido</a></p>
<p><a href="modificar_pedido.php">Modificar/Eliminar Pedido</a></p>
<p><a href="registrar_entrega_pedido.php">Registrar entrega Pedido</a></p>
<p><a href="listar_pedidos_solicitados.php">Listar Pedidos Solicitados</a></p>
<p><a href="listar_pedidos_entregados.php">Listar Pedidos Entregados</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p></body>
</html>
