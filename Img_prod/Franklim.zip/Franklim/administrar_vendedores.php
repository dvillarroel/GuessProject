<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE VENDEDORES</p>
<p>&nbsp;</p>
<p><a href="registrar_vendedor.php">(+) Registrar un nuevo Vendedor</a></p>
<p><a href="actualizar_vendedor.php">Actualizar Datos Vendedor existente</a></p>
<p><a href="dar_baja_vendedor.php">Deshabilitar Vendedor</a></p>


<p>&nbsp;</p>
<p align="center"><a href="Administrar_cuentas.php">VOLVER ATRAS</a></p>
<p>&nbsp;</p>

<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
