<? 
require_once("manejomysql.php");
conectar_bd();
//$cod=$_GET['cu'];

//echo $cod;
//echo $consulta;
$queryuser = mysql_query("SELECT cod_user FROM session") or die("no se realizo");
$querydatos = sacar_registro_bd($queryuser);
$consultauser = mysql_query("SELECT cod_rol FROM persona where cod_usuario=".$querydatos['cod_user']) or die("no se realizo");
$querydatosuser = sacar_registro_bd($consultauser);

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<LINK 
href="hoja_de_estilo.css" type=text/css 
rel=stylesheet>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<SCRIPT language=JavaScript type=text/JavaScript>



<!--



















function MM_reloadPage(init) {  //reloads the window if Nav4 resized



  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {



    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}



  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();



}



MM_reloadPage(true);







function MM_preloadImages() { //v3.0



  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();



    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)



    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}



}







function MM_findObj(n, d) { //v4.01



  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {



    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}



  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];



  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);



  if(!x && d.getElementById) x=d.getElementById(n); return x;



}







function MM_showHideLayers() { //v6.0



  var i,p,v,obj,args=MM_showHideLayers.arguments;



  for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];



    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
//-->
</SCRIPT>
<META content="MSHTML 6.00.2745.2800" name=GENERATOR>
<body  background="body2.jpg">

<div id="menusensor" 
style="Z-INDEX: 4; LEFT: 120px; WIDTH: 149px; POSITION: absolute; TOP: 4px; HEIGHT: 272px" onMouseOver="MM_showHideLayers('Administ','','hide', 'Carreras','','hide', 'Productos','','hide', 'Pedidos','','hide', 'Cobros','','hide', 'Costos','','hide', 'Reportes','','hide');">
</div>
	
<div id="Administ" style="VISIBILITY: hidden; position:absolute; left:116px; top:53px; width:111px; height:74px; z-index:5"> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="registrar_cliente.php" target="mainFrame">Registrar Cliente</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="actualizar_cliente.php" target="mainFrame">Modificar Cliente</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="dar_baja_cliente.php" target="mainFrame">Dar de Baja</a></td>
    </tr>
  </table>
</div>
<div id="Carreras" style="VISIBILITY: hidden; position:absolute; left:115px; top:76px; width:111px; height:73px; z-index:6">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="registrar_cliente_equipo.php" target="mainFrame">Asignar Equipo</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="buscar_equipo.php" target="mainFrame">Modificar Asignacion</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="quitar_equipo.php" target="mainFrame">Quitar Equipo</a></td>
    </tr>
  </table>
</div>
<div id="Productos" style="VISIBILITY: hidden; position:absolute; left:115px; top:99px; width:111px; height:49px; z-index:7">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="registrar_producto.php" target="mainFrame">Registrar Producto</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="actualizar_producto.php" target="mainFrame">Modificar Producto</a></td>
    </tr>
   </table>
</div>
<div id="Pedidos" style="VISIBILITY: hidden; position:absolute; left:115px; top:122px; width:111px; height:115px; z-index:8">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="buscar_cliente_pedido.php" target="mainFrame">Registrar Pedido</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="modificar_pedido.php" target="mainFrame">Modificar Pedido</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="registrar_entrega_pedido.php" target="mainFrame">Registrar Entrega</a></td>
    </tr>
	 <tr>
      <td class="campotablas3"><a href="listar_pedidos_solicitados.php" target="mainFrame">Pedidos Solicitados</a></td>
    </tr>
	 <tr>
      <td class="campotablas3"><a href="listar_pedidos_entregados.php" target="mainFrame">Pedidos Entregados</a></td>
    </tr>
  </table>
</div>
<div id="Costos" style="VISIBILITY: hidden; position:absolute; left:115px; top:168px; width:111px; height:23px; z-index:9">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="registrar_costo.php" target="mainFrame">Registrar Costo</a></td>
    </tr>
   </table>
</div>
<div id="Reportes" style="VISIBILITY: hidden; position:absolute; left:115px; top:214px; width:111px; height:78px; z-index:10">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td class="campotablas3"><a href="listar_clientes.php" target="mainFrame">Lista de Clientes</a></td>
    </tr>
    <tr>
      <td class="campotablas3"><a href="mostrar_ganancias_pedidos.php" target="mainFrame">Ingresos Por Pedidos</a></td>
    </tr>
	<tr>
      <td class="campotablas3">Cuentas por Cobrar</td>
    </tr>
	<tr>
      <td class="campotablas3"><a href="seleccionar_periodo.php" target="mainFrame">Periodo de Inactividad</a></td>
    </tr>
   </table>
</div>

<div id="Cobros" style="VISIBILITY: hidden; position:absolute; left:115px; top:145px; width:111px; height:75px; z-index:11">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <td class="campotablas3">Cuentas por Cobrar</td>
    </tr>
	<tr>
      <td class="campotablas3">Registrar Cobro</td>
    </tr>
	
	<tr>
      <td class="campotablas3">Modificar/Cancelar Cobro</td>
    </tr>	
   </table>
</div>



<table width="175" cellpadding="0" cellspacing="0">
  			<tbody>
    			<tr > 
      				<td height="31" ><img src="1C.gif" alt="" style="display: block;" height="30" width="19"></td>
      				<td width="100%" background="3.gif" class="titl">MENU DE OPCIONES</td>
      				<td ><img src="2C.gif" alt="" style="display: block;" height="30" width="19"></td>
    			</tr>
  			</tbody>
		</table>

<table width="175"  cellpadding="0" cellspacing="0">
<tbody>


<tr  >
      <td  class="campotablas3"><a href="principal_target.php" target="mainFrame" onMouseOver="MM_showHideLayers('Administ','','hide', 'Carreras','','hide', 'Productos','','hide', 'Pedidos','','hide',  'Cobros','','hide', 'Costos','','hide','Reportes','','hide');">Principal</a> 
      </td>
</tr>

<? if($querydatosuser['cod_rol'] != 1)
{
echo '	<tr  >
      <td  class="campotablas3"><a href="administrar_cuentas.php" target="mainFrame">Administrar Cuentas</a> 
      </td>
</tr>';

	
	}
?>



	
	
	<tr  >
		
			<td  class="campotablas3" >
			<a href="administrar_clientes.php" target="mainFrame" onMouseOver="MM_showHideLayers('Administ','','hide', 'Carreras','','hide', 'Productos','','hide', 'Pedidos','','hide', 'Cobros','','hide', 'Costos','','hide','Reportes','','hide');">Administrar Clientes</a> </td>
		
		</tr>
		
		<tr >
	
		
		</tr>
		
	<tr  >
		
			<td  class="campotablas3"><a href="administrar_productos.php" target="mainFrame" onMouseOver="MM_showHideLayers('Administ','','hide', 'Carreras','','hide', 'Productos','','hide', 'Pedidos','','hide', 'Cobros','','hide', 'Costos','','hide','Reportes','','hide');">Administrar Productos</a> </td>
		
		</tr>
		
		
	<tr  >
		
			<td  class="campotablas3"><a href="administrar_pedidos.php" target="mainFrame">Administrar Pedidos</a> </td>
		
		</tr>
		
			<tr  >
		
			<td  class="campotablas3"><a href="administrar_cobros.php" target="mainFrame">Administrar Cobros</a> </td>
		
		</tr>
		
		<tr  >
		
			<td  class="campotablas3"><a href="administrar_costos.php" target="mainFrame">Administrar Costos</a> </td>
		
			</tr>
		
	</tr>
		
			<td  class="campotablas3"><a href="buscar_cliente.php" target="mainFrame">Buscar Productos/clientes </a> </td>
		
		</tr>	
	
	<tr >
		
			<td  class="campotablas3"><a href="reportes.php" target="mainFrame">Reportes</a> </td>
		 
		</tr>	
		</tr>	
	
		</tr>
		
			<td  class="campotablas3"><a href="salir.php" target="_parent">Salir</a></td>
		
		</tr>
	

 

</tbody>
</table> 
<table width="175"  cellpadding="0" cellspacing="0">
<tbody><tr>
<td  width="18"><img src="6.gif" alt="" style="display: block;" height="30" width="19"></td>
<td  width="100%" background="5.gif"></td>
<td ><img src="4.gif" alt="" style="display: block;" height="30" width="19"></td></tr>
</tbody></table>





</body>
</html>
