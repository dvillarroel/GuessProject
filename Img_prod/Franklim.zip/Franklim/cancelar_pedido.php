<?php

require_once("manejomysql.php");
conectar_bd();

$codigo_pedido=$_GET['id_pedido'];


consulta_bd("DELETE FROM detalle_pedido where cod_pedido=".$codigo_pedido );
consulta_bd("delete from pedido where cod_pedido=".$codigo_pedido );

header ("Location:administrar_pedidos.php");
exit;
?> 