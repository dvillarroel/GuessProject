<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE CUENTAS</p>
<p>&nbsp;</p>
<p><a href="administrar_vendedores.php">Administrar Vendedores</a></p>
<p><a href="administrar_administradores.php">Administrar Administradores</a></p>


<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
