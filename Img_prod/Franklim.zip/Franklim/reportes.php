<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>REPORTES DEL SISTEMA</p>
<p>&nbsp;</p>
<p><a href="listar_clientes.php">Listar Clientes </a></p>
<p><a href="listar_productos_minstock.php">Listar Productos que estan por debajo del stock Minimo</a></p>
<p><a href="listar_productos_pedido.php">Listar Productos para pedido</a></p>
<p><a href="listar_productos_impresion.php">Imprimir Inventario</a></p>
<p><a href="Exportar_inventarios_excel.php">Exportar Inventarios Excel</a></p>
<p><a href="Exportar_inventarios_pfg.php">Exportar Inventarios PDF</a></p>
<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
