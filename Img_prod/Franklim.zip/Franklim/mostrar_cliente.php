<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td class="panel-titulo2"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="16"></td>
    <td class="panel-titulo3" align="center">&nbsp;</td>
    <td class="panel-titulo3" width="100%" align="center"><font class="titulo_formulario">INFORMACION 
      CLIENTE</font></td>
    <td class="panel-titulo"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="16"></td>
  </tr>
</table>
<form action="../registrar_alumno.php" method="post">
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td height="31" class="panel-right"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
        <td class="panel-main" width="100%"></td>
        <td class="panel-left"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
      </tr>
    </tbody>
  </table>
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td class="border-left"><img src="../news.php_files/blank.gif" alt="" style="display: block;" height="1"></td>
        <td> <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFCC" bgcolor="#E4E4E4" style="TABLE-LAYOUT: fixed">
            <tr> 
              <td colspan="4"  class="title">INFORMACI&Oacute;N CLIENTE</td>
            </tr>
            <tr> 
              <td width="25%" class="campotablas">Codigo Cliente:</td>
              <td width="25%" class="campotablas">&nbsp; </td>
              <td width="25%" class="campotablas">Nro. Carnet de Identidad:</td>
              <td width="25%" class="campotablas">&nbsp; </td>
            </tr>
            <tr> 
              <td class="campotablas">Apellido Paterno:</td>
              <td class="campotablas">&nbsp; </td>
              <td class="campotablas">Apellido Materno:</td>
              <td class="campotablas">&nbsp; </td>
            </tr>
            <tr> 
              <td height="27"class="campotablas"> Nombres:</td>
              <td class="campotablas">&nbsp; </td>
              <td class="campotablas">Direccion:</td>
              <td class="campotablas">&nbsp; </td>
            </tr>
            <tr> 
              <td class="campotablas">Telefono:</td>
              <td class="campotablas">&nbsp;</td>
              <td class="campotablas">Correo Electronico:</td>
              <td class="campotablas">&nbsp;</td>
            </tr>
          </table></td>
        <td class="border-right"><img src="../news.php_files/blank.gif" alt="" style="display: block;" height="8" width="18"></td>
      </tr>
    </tbody>
  </table>
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td width="18" height="18" class="border-bleft"></td>
        <td class="border-bmain"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="1"></td>
        <td class="border-bright"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
      </tr>
    </tbody>
  </table>
  <br>
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td height="31" class="panel-right"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
        <td class="panel-main" width="100%"></td>
        <td class="panel-left"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
      </tr>
    </tbody>
  </table>
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td class="border-left"><img src="../news.php_files/blank.gif" alt="" style="display: block;" height="1"></td>
        <td> <center>
            <table width="100%"  border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFCC" bgcolor="#E4E4E4" style="TABLE-LAYOUT: fixed">
              <tr> 
                <td width="32%" height="24"  class="title" >OBSERVACIONES</td>
              </tr>
              <tr> 
                <td > <textarea name="HOLA" class="interiorArea" style="WIDTH: 100%; HEIGHT: 60px" ></textarea> 
                </td>
              </tr>
            </table>
          </center></td>
        <td class="border-right"><img src="../images/blank.gif" alt="" style="display: block;" height="8" width="18"></td>
      </tr>
    </tbody>
  </table>
  <table width="80%" align="center" cellpadding="0" cellspacing="0">
    <tbody>
      <tr> 
        <td class="border-bleft" width="18"></td>
        <td class="border-bmain"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="1"></td>
        <td class="border-bright"><img src="../images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
      </tr>
    </tbody>
  </table>
</form>
</body>
</html>
