<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE COSTOS</p>
<p>&nbsp;</p>
<p><a href="registrar_costo.php">Registrar Costo</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">Volver a la pagina Principal</a></p>
</body>
</html>
