<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>EQUIPOS</p>
<p>&nbsp;</p>
<p><a href="resumen_equipos_empresa.php">Resumen de Equipos</a></p>
<p><a href="adicionar_equipos.php">Actualizar Numero de Equipos</a></p>



<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
