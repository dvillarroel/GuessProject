<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE PRODUCTOS</p>
<p>&nbsp;</p>
<p><a href="registrar_producto.php">Registrar Nuevo Producto</a></p>
<p><a href="actualizar_producto.php">Modificar Informacion de Producto</a></p>
<p><a href="cargar_producto.php">Cargar productos</a></p>
<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
