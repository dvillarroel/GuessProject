<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE CLIENTES</p>
<p>&nbsp;</p>
<p><a href="registrar_cliente.php">Registrar Nuevo Cliente</a></p>
<p><a href="actualizar_cliente.php">Modificar Informacion de Cliente</a></p>
<p><a href="eliminar_cliente.php">Eliminar Cliente de los registros</a></p>
<p><a href="dar_baja_cliente.php">Dar de Baja a un cliente</a></p>


<p>&nbsp;</p>
<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
