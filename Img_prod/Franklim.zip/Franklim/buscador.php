<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<table width="40%" border="0" align="center" cellpadding="0" cellspacing="0">
	<tr>
    	<td class="panel-titulo2"><img src="images/blank.gif" alt="" style="display: block;" height="18" width="16"></td>
    	
    <td class="panel-titulo3" width="100%" align="center"><font class="titulo_formulario"> 
      Busqueda </font></td>
    	<td class="panel-titulo"><img src="images/blank.gif" alt="" style="display: block;" height="18" width="16"></td>
 	</tr>
</table>
<p>&nbsp;</p><table width="80%" align="center" cellpadding="0" cellspacing="0"><tbody>
	<tr> 
    	<td height="31" class="panel-right"><img src="images/blank.gif" alt="" style="display: block;" height="15" width="18"></td>
    	<td class="panel-main" width="100%"></td>
    	<td class="panel-left"><img src="images/blank.gif" alt="" style="display: block;" height="10" width="18"></td>
 	</tr></tbody>
</table>

<table width="80%" align="center" cellpadding="0" cellspacing="0"><tbody>
	<tr>
      	<td class="border-left"></td>
		<td> 
			<table width="56%"  border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#FFFFCC" bgcolor="#E4E4E4" style="TABLE-LAYOUT: fixed">
				
          <tr> 
            <td   colspan="2" class="etiquetaa">Ingresar Busqueda:</td>
			  <td width="50%"><input type="text" name="ncu" maxlength="30" tabIndex="1" class="Formulario" selected ></td>
			 
			  
				</tr>
				
				<tr> 
            		
            <td colspan="2" class="etiquetaa"></td>
			  
            <td>&nbsp;</td>
			  
			  
				</tr>
  			  
			</table>
		</td>
		<td class="border-right"><img src="news.php_files/blank.gif" alt="" style="display: block;" height="8" width="18"></td>
	</tr></tbody>
</table>

<table width="80%" align="center" cellpadding="0" cellspacing="0"><tbody>
	<tr>
		<td class="borderbleft" width="18"></td>
		<td class="border-bmain"><img src="images/blank.gif" alt="" style="display: block;" height="18" width="1"></td>
		<td class="border-bright"><img src="images/blank.gif" alt="" style="display: block;" height="18" width="18"></td>
	</tr></tbody>
</table>


</body>
</html>
