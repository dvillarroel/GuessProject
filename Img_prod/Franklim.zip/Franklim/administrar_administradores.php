<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body background="body2.jpg">
<p>ADMINISTRACION DE ADMINSTRADORES DEL SISTEMA</p>
<p>&nbsp;</p>
<p><a href="registrar_administrador.php">(+) Registrar un nuevo Administrador</a></p>
<p><a href="actualizar_administrador.php">Actualizar Datos Administrador existente</a></p>
<p><a href="dar_baja_administrador.php">Deshabilitar Administrador</a></p>


<p>&nbsp;</p>
<p align="center"><a href="Administrar_cuentas.php">VOLVER ATRAS</a></p>
<p>&nbsp;</p>

<p align="center"><a href="principal_target.php">VOLVER A LA PAGINA PRINCIPAL</a></p>
</body>
</html>
